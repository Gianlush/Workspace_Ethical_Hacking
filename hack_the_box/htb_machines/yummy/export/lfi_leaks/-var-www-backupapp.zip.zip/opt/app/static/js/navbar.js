function getCookie(name) {
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);
    if (parts.length === 2) return parts.pop().split(';').shift();
}

// Navbar items for logged out users
const loggedOutItems = `
    <li><a class="nav-link scrollto active" href="#hero">Home</a></li>
    <li><a class="nav-link scrollto" href="/dashboard">Dashboard</a></li>
    <li><a class="nav-link scrollto" href="#menu">Menu</a></li>
    <li><a class="nav-link scrollto" href="#specials">Specials</a></li>
    <li><a class="nav-link scrollto" href="#events">Events</a></li>
    <li><a class="nav-link scrollto" href="#chefs">Chefs</a></li>
    <li><a class="nav-link scrollto" href="#gallery">Gallery</a></li>
    <li><a class="nav-link scrollto" href="/login">Login</a></li>
    <li><a class="nav-link scrollto" href="/register">Register</a></li>
`;

// Navbar items for logged in users
const loggedInItems = `
    <li><a class="nav-link scrollto active" href="#hero">Home</a></li>
    <li><a class="nav-link scrollto" href="/dashboard">Dashboard</a></li>
    <li><a class="nav-link scrollto" href="/#menu">Menu</a></li>
    <li><a class="nav-link scrollto" href="/#specials">Specials</a></li>
    <li><a class="nav-link scrollto" href="/#events">Events</a></li>
    <li><a class="nav-link scrollto" href="/#chefs">Chefs</a></li>
    <li><a class="nav-link scrollto" href="/#gallery">Gallery</a></li>
    <li><a class="nav-link scrollto" href="/logout">Logout</a></li>
`;

// Determine which set of items to use
const navbarList = document.getElementById('navbar-list');
if (getCookie('X-AUTH-Token')) {
    navbarList.innerHTML = loggedInItems;
} else {
    navbarList.innerHTML = loggedOutItems;
}