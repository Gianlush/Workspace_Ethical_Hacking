const now = new Date();
const hours = String(now.getHours()).padStart(2, '0'); // Pads single-digit hours
const minutes = String(now.getMinutes()).padStart(2, '0'); // Pads single-digit minutes

// Set the value of the time input to the current time
document.getElementById('time').value = `${hours}:${minutes}`;
// Get today's date in the format YYYY-MM-DD
const today = new Date().toISOString().split('T')[0];
// Set the value of the date input to today's date
document.getElementById('date').value = today;