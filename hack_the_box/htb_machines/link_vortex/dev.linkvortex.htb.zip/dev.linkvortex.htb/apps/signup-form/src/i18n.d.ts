declare module '@tryghost/i18n';
