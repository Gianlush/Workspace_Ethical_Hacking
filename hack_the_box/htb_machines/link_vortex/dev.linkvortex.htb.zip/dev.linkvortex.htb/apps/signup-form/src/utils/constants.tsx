export const ROOT_DIV_CLASS = 'gh-signup-root';
