const assert = require('assert/strict');

describe('Hello world', function () {
    it('Runs a test', function () {
        // TODO: Write me!
        assert.ok(require('../../index'));
    });
});
