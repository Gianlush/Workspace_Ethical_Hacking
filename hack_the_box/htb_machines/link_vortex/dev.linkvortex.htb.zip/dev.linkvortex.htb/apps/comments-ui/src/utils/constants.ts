// Note: do not use ghost-comments as that makes the #ghost-comments scrolling unreliable because we inject this div after page load!
export const ROOT_DIV_ID = 'ghost-comments-root';
