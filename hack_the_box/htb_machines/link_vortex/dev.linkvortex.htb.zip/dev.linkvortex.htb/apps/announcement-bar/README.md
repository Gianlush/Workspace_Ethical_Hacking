# Announcement Bar

## Development

### Pre-requisites

- Run `yarn` in Ghost monorepo root
- Run `yarn` in this directory

### Running via Ghost `yarn dev` in root folder

You can automatically start the announcement-bar dev server when developing Ghost by running Ghost (in root folder) via `yarn dev --announcementbar`.

# Copyright & License 

Copyright (c) 2013-2023 Ghost Foundation - Released under the [MIT license](LICENSE).
