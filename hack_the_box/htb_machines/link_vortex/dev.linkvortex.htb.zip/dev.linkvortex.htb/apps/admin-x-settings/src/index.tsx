import './styles/index.css';
import App from './App.tsx';

export {
    App as AdminXApp
};
