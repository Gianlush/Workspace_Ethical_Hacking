docker build . -t very-easy-sqli
docker run -it -d -p 1337:1337 very-easy-sqli
