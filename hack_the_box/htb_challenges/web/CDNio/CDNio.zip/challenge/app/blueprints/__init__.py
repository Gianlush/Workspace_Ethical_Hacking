from .main import main_bp
from .bot import bot_bp
from .auth import auth_bp