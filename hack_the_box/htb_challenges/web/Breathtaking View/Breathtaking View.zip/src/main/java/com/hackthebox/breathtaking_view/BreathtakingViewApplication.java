package com.hackthebox.breathtaking_view;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BreathtakingViewApplication {

	public static void main(String[] args) {
		SpringApplication.run(BreathtakingViewApplication.class, args);
	}

}
