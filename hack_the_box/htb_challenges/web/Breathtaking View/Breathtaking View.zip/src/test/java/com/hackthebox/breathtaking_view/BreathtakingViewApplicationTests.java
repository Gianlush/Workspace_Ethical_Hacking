package com.hackthebox.breathtaking_view;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BreathtakingViewApplicationTests {

	@Test
	void contextLoads() {
	}

}
