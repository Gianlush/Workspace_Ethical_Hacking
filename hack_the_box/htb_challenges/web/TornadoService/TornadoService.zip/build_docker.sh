#!/bin/bash
docker rm -f web_tornado_service
docker build --tag=web_tornado_service .
docker run -p 2333:1337 --rm --name=web_tornado_service -d -it web_tornado_service 