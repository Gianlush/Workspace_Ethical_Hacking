<?php

class Spaghetti
{
    public $sauce;
    public $noodles;
    public $portion;

    public function __get($tomato)
    {
        file_put_contents('/var/www/html/log.txt', 'get spaghetti    ', FILE_APPEND);
        ($this->sauce)();
    }
}