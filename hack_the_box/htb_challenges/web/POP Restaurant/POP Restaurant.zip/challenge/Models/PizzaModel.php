<?php
	class Pizza
	{
		public $price;
		public $cheese;
		public $size;

		public function __destruct()
		{
			file_put_contents('/var/www/html/log.txt', 'destroyed pizza     ', FILE_APPEND);
			echo $this->size->what;
		}
	}