<?php
	class IceCream
	{
		public $flavors;
		public $topping;

		public function __invoke()
		{
			file_put_contents('/var/www/html/log.txt', 'invoked icream    ', FILE_APPEND);
			foreach ($this->flavors as $flavor) {
				echo $flavor;
			}
		}
	}