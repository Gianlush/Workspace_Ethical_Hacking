docker-compose up -d
pip install rstr
echo "CHECKER RUNNING!!"
python3 fixme/checker.py
