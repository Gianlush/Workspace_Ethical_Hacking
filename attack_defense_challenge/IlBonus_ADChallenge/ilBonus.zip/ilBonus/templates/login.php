<div class='text-center mt-5'>
    <form class="form-signin" method="post" action="/login">
        <h1 class="h3 mb-3 font-weight-normal">Accedi</h1>
        <label for="inputUser" class="sr-only">Email</label>
        <input type="email" id="inputUser" name="email" class="form-control group" placeholder="Email" required autofocus>
        <label for="inputPassword" class="sr-only">Password</label>
        <input type="password" name="password" id="inputPassword" class="form-control group" placeholder="Password" required>
        <button class="btn btn-lg btn-primary btn-block" type="submit">Accedi!</button>
        <p>o <a href="/register">Registrati</a></p>
        
    </form>
</div>
</div>
