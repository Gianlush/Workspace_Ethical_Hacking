#!/bin/bash
chmod 777 ./logs
chmod 777 ./uploads 
docker-compose up --build -d
